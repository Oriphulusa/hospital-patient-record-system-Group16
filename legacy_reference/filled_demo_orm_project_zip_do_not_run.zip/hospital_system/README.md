# Hospital Patient Record System — Clean Runnable Version

This is a **Django-only** hospital system using **PostgreSQL** and Django templates. It is designed to run as one combined project: backend + HTML frontend together.

## What is included

- Role-based login: admin, doctor, nurse, patient
- Patients, appointments, consultations and vitals
- Pharmacy, laboratory, wards/admissions
- Insurance and billing
- Payment proof upload and payment verification
- Appointment email notifications using Django console email backend
- PostgreSQL raw SQL schema in `sql/schema.sql`
- Demo seed data in `sql/seed.sql` and demo users through `python manage.py seed`

## Important

Django models use `managed = False`. That means Django does **not** create the app tables. You must run `sql/schema.sql` first in PostgreSQL/pgAdmin.

## Quick setup on macOS/Linux

```bash
cd hospital_system
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Create a PostgreSQL database called `hospital_db`, then run:

```bash
psql -U postgres -h localhost -p 5432 -d hospital_db -f sql/schema.sql
psql -U postgres -h localhost -p 5432 -d hospital_db -f sql/seed.sql
```

Set database details if your password/user are different:

```bash
export DB_NAME=hospital_db
export DB_USER=postgres
export DB_PASSWORD=postgres
export DB_HOST=localhost
export DB_PORT=5432
```

Create demo users:

```bash
python manage.py seed
```

Run:

```bash
python manage.py runserver
```

Open: `http://127.0.0.1:8000/`

## Demo logins

All passwords are:

```text
password123
```

Usernames:

```text
admin
doctor1
nurse1
patient1
```

## Appointment email feature

When an appointment is created or edited, the system sends appointment notification emails to the patient and doctor. For demo safety, emails are printed in the terminal using:

```python
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
```

This proves the email feature works without needing Gmail credentials.

## Files to run in pgAdmin/PostgreSQL

Run in this order:

1. `sql/schema.sql`
2. `sql/seed.sql`
3. `python manage.py seed`
4. `python manage.py runserver`

## Final note

This version is intended as a separate clean test copy. Open it separately from your real group repo first. Once it runs, your group can compare and decide what to copy into the main GitHub project.


## Filled Demo Data

This version includes an enhanced Django seed command. It creates:

- Admin/reception staff accounts
- 4 doctors
- 3 nurses
- 6 patient login accounts
- 12 patient records
- appointments for today and future dates
- consultations, vitals, prescriptions, lab orders, wards, beds, admissions, insurance records, bills, bill items, and payments

Run it after `sql/schema.sql` and `sql/seed.sql`:

```bash
DB_NAME=hospital_db DB_USER=postgres DB_PASSWORD='YOUR_POSTGRES_PASSWORD' DB_HOST=localhost DB_PORT=5432 python manage.py seed
```

Demo passwords are all:

```text
password123
```

Extra logins:

```text
doctor2 / password123
doctor3 / password123
doctor4 / password123
nurse2 / password123
nurse3 / password123
patient2 / password123
patient3 / password123
patient4 / password123
patient5 / password123
patient6 / password123
```

Appointment email notifications use Django's console email backend by default. This means the email appears in the VS Code terminal when an appointment is created or edited.
