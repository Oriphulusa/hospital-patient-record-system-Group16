#!/usr/bin/env bash
set -e
source venv/bin/activate
export DB_NAME=${DB_NAME:-hospital_db}
export DB_USER=${DB_USER:-postgres}
export DB_PASSWORD=${DB_PASSWORD:-postgres}
export DB_HOST=${DB_HOST:-localhost}
export DB_PORT=${DB_PORT:-5432}
python manage.py runserver
