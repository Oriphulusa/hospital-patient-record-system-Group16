from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import Appointment
from .forms import AppointmentForm


def send_appointment_notifications(appointment):
    patient_email = getattr(appointment.patient.user, 'email', '') if appointment.patient.user else ''
    doctor_email = getattr(appointment.doctor, 'email', '')
    when = appointment.scheduled_for.strftime('%d %B %Y at %H:%M')
    patient_name = appointment.patient.full_name()
    doctor_name = appointment.doctor.get_full_name() or appointment.doctor.username

    if patient_email:
        send_mail(
            'Appointment Confirmation',
            f'Dear {patient_name},\n\nYour appointment with Dr. {doctor_name} has been booked for {when}.\n\nReason: {appointment.reason}\n\nHospital Patient Record System',
            settings.DEFAULT_FROM_EMAIL,
            [patient_email],
            fail_silently=True,
        )
    if doctor_email:
        send_mail(
            'New Appointment Scheduled',
            f'Dear Dr. {doctor_name},\n\nA new appointment has been scheduled with {patient_name} for {when}.\n\nReason: {appointment.reason}\n\nHospital Patient Record System',
            settings.DEFAULT_FROM_EMAIL,
            [doctor_email],
            fail_silently=True,
        )

@login_required
def appointment_list(request):
    u=request.user; qs=Appointment.objects.select_related('patient','doctor')
    if u.is_doctor(): qs=qs.filter(doctor=u)
    elif u.is_patient(): qs=qs.filter(patient__user=u)
    return render(request,'appointments/list.html',{'appointments':qs})

@login_required
def appointment_create(request):
    if not (request.user.is_admin() or request.user.is_doctor()):
        return redirect('appointments:list')
    form = AppointmentForm(request.POST or None)
    if form.is_valid():
        appointment = form.save()
        send_appointment_notifications(appointment)
        messages.success(request, 'Appointment saved. Email notifications were generated in the terminal/demo console.')
        return redirect('appointments:list')
    return render(request,'appointments/form.html',{'form':form,'title':'New Appointment'})

@login_required
def appointment_edit(request, pk):
    a = get_object_or_404(Appointment, pk=pk)
    if not (request.user.is_admin() or request.user==a.doctor):
        return redirect('appointments:list')
    form = AppointmentForm(request.POST or None, instance=a)
    if form.is_valid():
        appointment = form.save()
        send_appointment_notifications(appointment)
        messages.success(request, 'Appointment updated. Email notifications were generated in the terminal/demo console.')
        return redirect('appointments:list')
    return render(request,'appointments/form.html',{'form':form,'title':'Edit Appointment'})
