#!/usr/bin/env bash
set -e
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
echo "Now create PostgreSQL DB hospital_db and run sql/schema.sql + sql/seed.sql, then: python manage.py seed && python manage.py runserver"
