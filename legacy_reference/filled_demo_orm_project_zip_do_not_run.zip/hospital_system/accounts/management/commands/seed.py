from decimal import Decimal
from datetime import date, timedelta, time
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone

from patients.models import Patient
from appointments.models import Appointment
from consultations.models import Consultation, Vitals
from pharmacy.models import Medication, Prescription
from laboratory.models import LabTest, LabOrder
from wards.models import Ward, Bed, Admission
from insurance.models import InsuranceProvider, PatientInsurance
from billing.models import Bill, BillItem, Payment

User = get_user_model()


def aware_at(day, hour, minute=0):
    """Return an aware datetime in the current Django timezone."""
    return timezone.make_aware(timezone.datetime.combine(day, time(hour, minute)))


class Command(BaseCommand):
    help = 'Seed full demo data for the Hospital Patient Record System. Login password for all demo users: password123'

    def user(self, username, role, first_name, last_name, email='', phone='', specialization='', is_staff=False, is_superuser=False):
        defaults = {
            'role': role,
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'phone': phone,
            'specialization': specialization,
            'is_staff': is_staff or is_superuser,
            'is_superuser': is_superuser,
            'is_active': True,
        }
        u, created = User.objects.get_or_create(username=username, defaults=defaults)
        changed = False
        for k, v in defaults.items():
            if getattr(u, k) != v:
                setattr(u, k, v); changed = True
        if created or not u.has_usable_password():
            u.set_password('password123'); changed = True
        if changed:
            u.save()
        return u

    def patient(self, mrn, first, last, dob, gender, **extra):
        obj, _ = Patient.objects.update_or_create(
            mrn=mrn,
            defaults={
                'first_name': first,
                'last_name': last,
                'date_of_birth': dob,
                'gender': gender,
                'phone': extra.get('phone', ''),
                'address': extra.get('address', ''),
                'blood_group': extra.get('blood_group', ''),
                'emergency_contact': extra.get('emergency_contact', ''),
                'allergies': extra.get('allergies', ''),
                'user': extra.get('user'),
            }
        )
        return obj

    def handle(self, *args, **kwargs):
        today = timezone.localdate()

        # ------------------------------------------------------------------
        # 1) Demo users: admin, doctors, nurses, and patient accounts
        # ------------------------------------------------------------------
        admin = self.user('admin', 'admin', 'System', 'Admin', 'admin@hprs.co.za', '+27821230001', is_staff=True, is_superuser=True)
        reception1 = self.user('reception1', 'admin', 'Zanele', 'Khumalo', 'reception1@hprs.co.za', '+27821230008', is_staff=True)
        reception2 = self.user('reception2', 'admin', 'Sipho', 'Mthembu', 'reception2@hprs.co.za', '+27821230009', is_staff=True)

        doctors = {
            'doctor1': self.user('doctor1', 'doctor', 'Thabo', 'Dlamini', 'dr.dlamini@hprs.co.za', '+27821230002', 'Cardiology'),
            'doctor2': self.user('doctor2', 'doctor', 'Aisha', 'Patel', 'dr.patel@hprs.co.za', '+27821230003', 'Paediatrics'),
            'doctor3': self.user('doctor3', 'doctor', 'Karabo', 'Molefe', 'dr.molefe@hprs.co.za', '+27821230004', 'General Medicine'),
            'doctor4': self.user('doctor4', 'doctor', 'Michael', 'Naidoo', 'dr.naidoo@hprs.co.za', '+27821230005', 'Orthopaedics'),
        }
        nurses = {
            'nurse1': self.user('nurse1', 'nurse', 'Lerato', 'Nkosi', 'nurse.nkosi@hprs.co.za', '+27821230006'),
            'nurse2': self.user('nurse2', 'nurse', 'Bongani', 'Maseko', 'nurse.maseko@hprs.co.za', '+27821230007'),
            'nurse3': self.user('nurse3', 'nurse', 'Naledi', 'Sibanda', 'nurse.sibanda@hprs.co.za', '+27821230010'),
        }
        patient_users = {
            'patient1': self.user('patient1', 'patient', 'Mpho', 'Ndlovu', 'mpho.ndlovu@example.com', '+27831234561'),
            'patient2': self.user('patient2', 'patient', 'Ayanda', 'Mabena', 'ayanda.mabena@example.com', '+27831234562'),
            'patient3': self.user('patient3', 'patient', 'Lethabo', 'Mokoena', 'lethabo.mokoena@example.com', '+27831234563'),
            'patient4': self.user('patient4', 'patient', 'Zinhle', 'Khumalo', 'zinhle.khumalo@example.com', '+27831234564'),
            'patient5': self.user('patient5', 'patient', 'Tshepo', 'Molefe', 'tshepo.molefe@example.com', '+27831234565'),
            'patient6': self.user('patient6', 'patient', 'Nandi', 'Nkosi', 'nandi.nkosi@example.com', '+27831234566'),
        }

        # ------------------------------------------------------------------
        # 2) Patients adapted from the Phase 3 sample data into Django tables
        # ------------------------------------------------------------------
        patients = [
            self.patient('MRN0001', 'Mpho', 'Ndlovu', date(1998, 4, 12), 'M', user=patient_users['patient1'], phone='+27831234561', address='12 Nelson Mandela Drive, Mahikeng, North West, 2745', blood_group='O+', emergency_contact='Thandi Ndlovu +27839870001', allergies='Penicillin - severe'),
            self.patient('MRN0002', 'Ayanda', 'Mabena', date(2001, 8, 23), 'F', user=patient_users['patient2'], phone='+27831234562', address='45 Steve Biko Road, Pretoria, Gauteng, 0002', blood_group='A+', emergency_contact='Sibusiso Mabena +27839870002'),
            self.patient('MRN0003', 'Lethabo', 'Mokoena', date(2012, 11, 5), 'M', user=patient_users['patient3'], phone='+27831234563', address='88 Church Street, Johannesburg, Gauteng, 2001', blood_group='B+', emergency_contact='Nomvula Mokoena +27839870003', allergies='Peanuts - critical'),
            self.patient('MRN0004', 'Zinhle', 'Khumalo', date(1985, 2, 18), 'F', user=patient_users['patient4'], phone='+27831234564', address='19 Long Street, Cape Town, Western Cape, 8001', blood_group='AB+', emergency_contact='Bheki Khumalo +27839870004'),
            self.patient('MRN0005', 'Tshepo', 'Molefe', date(1979, 6, 30), 'M', user=patient_users['patient5'], phone='+27831234565', address='77 Dr James Moroka Avenue, Mahikeng, North West, 2745', blood_group='A-', emergency_contact='Kagiso Molefe +27839870005', allergies='Latex - moderate'),
            self.patient('MRN0006', 'Nandi', 'Nkosi', date(1995, 9, 14), 'F', user=patient_users['patient6'], phone='+27831234566', address='5 Florida Road, Durban, KwaZulu-Natal, 4001', blood_group='O-', emergency_contact='Themba Nkosi +27839870006'),
            self.patient('MRN0007', 'Kabelo', 'Radebe', date(1990, 1, 25), 'M', phone='+27831234567', address='101 Vilakazi Street, Soweto, Gauteng, 1804', blood_group='B-', emergency_contact='Palesa Radebe +27839870007', allergies='Aspirin - severe'),
            self.patient('MRN0008', 'Palesa', 'Tshabalala', date(2004, 3, 9), 'F', phone='+27831234568', address='28 Loop Street, Cape Town, Western Cape, 8001', blood_group='A+', emergency_contact='Refilwe Tshabalala +27839870008'),
            self.patient('MRN0009', 'Siphesihle', 'Dube', date(2010, 7, 21), 'M', phone='+27831234569', address='33 Pixley ka Seme Street, Durban, KwaZulu-Natal, 4001', blood_group='O+', emergency_contact='Lindiwe Dube +27839870009', allergies='Sulfa Drugs - moderate'),
            self.patient('MRN0010', 'Boitumelo', 'Seko', date(1999, 12, 2), 'F', phone='+27831234570', address='6 University Road, Potchefstroom, North West, 2531', blood_group='AB-', emergency_contact='Kgomotso Seko +27839870010'),
            self.patient('MRN0011', 'Refilwe', 'Motsumi', date(1988, 10, 18), 'F', phone='+27831234571', address='22 University Drive, Mahikeng, North West', blood_group='O+', emergency_contact='Neo Motsumi +27839870011'),
            self.patient('MRN0012', 'Olebogeng', 'Tau', date(1972, 5, 4), 'M', phone='+27831234572', address='14 Sekame Road, Mmabatho, North West', blood_group='A+', emergency_contact='Kea Tau +27839870012'),
        ]
        by_mrn = {p.mrn: p for p in patients}

        # ------------------------------------------------------------------
        # 3) Reference data: wards, beds, medication, lab tests, insurance
        # ------------------------------------------------------------------
        ward_specs = [
            ('General Ward A', 'Main adult inpatient ward', Decimal('850.00'), ['A-101','A-102','A-103','A-104','A-105','A-106']),
            ('ICU Ward', 'Intensive care unit', Decimal('2500.00'), ['ICU-01','ICU-02','ICU-03','ICU-04']),
            ('Paediatric Ward', 'Children under 12', Decimal('950.00'), ['P-011','P-012','P-013','P-014','P-015']),
            ('Maternity Ward', 'Maternity and postnatal care', Decimal('1200.00'), ['M-021','M-022','M-023']),
            ('Emergency Ward', 'Short stay emergency observation', Decimal('700.00'), ['E-006','E-007','E-008','E-009']),
        ]
        beds = {}
        for name, desc, rate, bed_nums in ward_specs:
            ward, _ = Ward.objects.update_or_create(name=name, defaults={'description': desc, 'daily_rate': rate})
            for num in bed_nums:
                bed, _ = Bed.objects.get_or_create(ward=ward, number=num, defaults={'is_occupied': False})
                beds[num] = bed

        med_specs = [
            ('Paracetamol 500mg', 'Analgesic and antipyretic tablet', 500, '2.50'),
            ('Ibuprofen 200mg', 'Anti-inflammatory tablet', 60, '3.20'),
            ('Amoxicillin 500mg', 'Antibiotic capsule', 250, '8.50'),
            ('Amlodipine 5mg', 'Antihypertensive tablet', 120, '4.75'),
            ('Salbutamol Inhaler', 'Bronchodilator inhaler', 30, '95.00'),
            ('Cefuroxime 250mg', 'Antibiotic tablet', 45, '12.00'),
            ('Diclofenac Gel 1%', 'Topical anti-inflammatory gel', 25, '55.00'),
            ('Metformin 500mg', 'Diabetes medication', 150, '2.10'),
            ('Cetirizine 10mg', 'Antihistamine tablet', 90, '1.80'),
            ('Oral Rehydration Salts', 'Rehydration sachet', 80, '6.00'),
        ]
        meds = {}
        for name, desc, stock, price in med_specs:
            med, _ = Medication.objects.update_or_create(name=name, defaults={'description': desc, 'stock': stock, 'unit_price': Decimal(price)})
            meds[name] = med

        lab_specs = [
            ('Complete Blood Count', '180.00'),
            ('Urinalysis', '120.00'),
            ('Blood Glucose', '85.00'),
            ('C-Reactive Protein', '220.00'),
            ('Troponin Test', '450.00'),
            ('Liver Function Test', '300.00'),
            ('Kidney Function Test', '280.00'),
            ('Chest X-Ray', '650.00'),
        ]
        tests = {}
        for name, price in lab_specs:
            test, _ = LabTest.objects.update_or_create(name=name, defaults={'price': Decimal(price)})
            tests[name] = test

        provider_specs = [
            ('Discovery Health', 'claims@discovery.example', 80),
            ('Bonitas', 'claims@bonitas.example', 70),
            ('Momentum Health', 'claims@momentum.example', 65),
            ('Medihelp', 'claims@medihelp.example', 75),
            ('NationalCare', 'claims@nationalcare.example', 60),
        ]
        providers = {}
        for name, contact, pct in provider_specs:
            prov, _ = InsuranceProvider.objects.update_or_create(name=name, defaults={'contact': contact, 'coverage_percent': pct})
            providers[name] = prov

        insurance_map = [
            ('MRN0001', 'Discovery Health', 'DH-100001', 80, date(2026, 12, 31)),
            ('MRN0003', 'Bonitas', 'BN-200002', 70, date(2026, 12, 31)),
            ('MRN0005', 'Momentum Health', 'MH-300003', 65, date(2026, 12, 31)),
            ('MRN0007', 'Medihelp', 'MHLP-400004', 75, date(2027, 1, 31)),
            ('MRN0009', 'NationalCare', 'NC-500005', 60, date(2026, 11, 30)),
            ('MRN0012', 'Discovery Health', 'DH-100012', 80, date(2026, 12, 31)),
        ]
        patient_insurance = {}
        for mrn, provider_name, policy, coverage, valid_until in insurance_map:
            pi, _ = PatientInsurance.objects.update_or_create(
                patient=by_mrn[mrn], provider=providers[provider_name], policy_number=policy,
                defaults={'coverage_percent': coverage, 'valid_until': valid_until, 'is_active': True}
            )
            patient_insurance[mrn] = pi

        # ------------------------------------------------------------------
        # 4) Appointments: today, upcoming, completed, cancelled, no-show
        # ------------------------------------------------------------------
        appointment_specs = [
            ('MRN0001', 'doctor1', 0, 9, 0, 'Chest pain and shortness of breath', 'scheduled', 'Priority review; ECG may be required.'),
            ('MRN0003', 'doctor2', 0, 10, 0, 'Child fever and cough', 'scheduled', 'Paediatric assessment.'),
            ('MRN0005', 'doctor4', -1, 11, 0, 'Back pain and mobility issue', 'completed', 'Seen and admitted for observation.'),
            ('MRN0002', 'doctor3', 2, 14, 0, 'Routine check-up', 'scheduled', ''),
            ('MRN0006', 'doctor3', -3, 8, 30, 'Follow-up appointment', 'no_show', 'Patient did not arrive.'),
            ('MRN0007', 'doctor1', -2, 13, 0, 'Cardiology review', 'cancelled', 'Patient requested reschedule.'),
            ('MRN0009', 'doctor2', 1, 15, 0, 'Paediatric review', 'scheduled', ''),
            ('MRN0010', 'doctor3', 0, 16, 0, 'General consultation', 'scheduled', ''),
            ('MRN0004', 'doctor3', 3, 9, 30, 'Hypertension follow-up', 'scheduled', ''),
            ('MRN0008', 'doctor2', 4, 12, 0, 'Vaccination and wellness check', 'scheduled', ''),
            ('MRN0011', 'doctor4', -5, 10, 30, 'Knee injury assessment', 'completed', 'Referred for X-ray.'),
            ('MRN0012', 'doctor1', 5, 11, 0, 'High blood pressure and dizziness', 'scheduled', ''),
            ('MRN0001', 'doctor1', 7, 9, 0, 'Cardiology follow-up', 'scheduled', ''),
            ('MRN0003', 'doctor2', 8, 10, 0, 'Paediatric follow-up', 'scheduled', ''),
            ('MRN0005', 'doctor4', 10, 14, 30, 'Orthopaedic follow-up', 'scheduled', ''),
        ]
        for mrn, doc_key, day_offset, hour, minute, reason, status, notes in appointment_specs:
            scheduled = aware_at(today + timedelta(days=day_offset), hour, minute)
            Appointment.objects.update_or_create(
                patient=by_mrn[mrn], doctor=doctors[doc_key], reason=reason,
                defaults={'scheduled_for': scheduled, 'status': status, 'notes': notes}
            )

        # ------------------------------------------------------------------
        # 5) Vitals, consultations, prescriptions, and lab orders
        # ------------------------------------------------------------------
        vitals_specs = [
            ('MRN0001', 'nurse1', 138, 88, 92, '37.1', 19, 97, '78.20', '172.0', 'Chest discomfort reported.'),
            ('MRN0003', 'nurse2', 102, 65, 110, '38.2', 24, 96, '34.00', '138.0', 'Fever and cough.'),
            ('MRN0005', 'nurse1', 128, 82, 76, '36.8', 18, 98, '85.50', '176.0', 'Lower back pain.'),
            ('MRN0007', 'nurse3', 150, 95, 88, '36.7', 20, 95, '91.00', '180.0', 'Cardiac observation.'),
            ('MRN0009', 'nurse2', 100, 64, 115, '38.5', 25, 96, '31.20', '135.0', 'Paediatric fever.'),
            ('MRN0010', 'nurse3', 118, 78, 82, '36.9', 17, 99, '62.80', '164.0', 'General consultation vitals.'),
            ('MRN0011', 'nurse1', 126, 80, 84, '36.6', 18, 99, '74.00', '168.0', 'Knee pain.'),
            ('MRN0012', 'nurse3', 160, 98, 90, '36.8', 19, 97, '88.00', '173.0', 'Dizziness and hypertension.'),
        ]
        for mrn, nurse_key, sys, dia, pulse, temp, rr, spo2, weight, height, notes in vitals_specs:
            Vitals.objects.update_or_create(
                patient=by_mrn[mrn], notes=notes,
                defaults={
                    'recorded_by': nurses[nurse_key], 'bp_systolic': sys, 'bp_diastolic': dia,
                    'pulse': pulse, 'temperature_c': Decimal(temp), 'respiratory_rate': rr,
                    'oxygen_saturation': spo2, 'weight_kg': Decimal(weight), 'height_cm': Decimal(height),
                }
            )

        consultation_specs = [
            ('MRN0005', 'doctor4', 'Lower back pain', 'Lower back pain with suspected lumbar strain', 'Ibuprofen and physiotherapy advice. Avoid heavy lifting.', 'Orthopaedic follow-up required.', ['Ibuprofen 200mg', 'Diclofenac Gel 1%'], ['Chest X-Ray']),
            ('MRN0007', 'doctor1', 'Chest tightness', 'Angina pectoris, unspecified', 'Amlodipine started. Monitor blood pressure twice daily.', 'Cardiology review.', ['Amlodipine 5mg'], ['Troponin Test', 'Complete Blood Count']),
            ('MRN0003', 'doctor2', 'Fever and cough', 'Acute upper respiratory infection', 'Paracetamol and hydration. Return if symptoms worsen.', 'Paediatric case.', ['Paracetamol 500mg'], ['C-Reactive Protein']),
            ('MRN0001', 'doctor1', 'Chest pain', 'Chest pain, unspecified', 'Observation and ECG referral.', 'Possible stress-related chest discomfort.', ['Salbutamol Inhaler'], ['Troponin Test']),
            ('MRN0009', 'doctor2', 'High fever', 'Fever, unspecified', 'Paediatric dose according to weight. Maintain hydration.', 'Monitor temperature.', ['Paracetamol 500mg', 'Cefuroxime 250mg'], ['Complete Blood Count']),
            ('MRN0011', 'doctor4', 'Knee injury', 'Soft tissue knee injury', 'Rest, ice, compression and anti-inflammatory gel.', 'No fracture signs.', ['Diclofenac Gel 1%'], ['Chest X-Ray']),
            ('MRN0012', 'doctor1', 'Dizziness and high BP', 'Hypertension review', 'Continue Amlodipine and monitor blood pressure.', 'Follow up in one week.', ['Amlodipine 5mg'], ['Kidney Function Test']),
            ('MRN0004', 'doctor3', 'Routine chronic review', 'Controlled hypertension', 'Lifestyle advice and repeat medication.', 'Stable.', ['Amlodipine 5mg'], ['Blood Glucose']),
        ]
        consults = []
        for mrn, doc_key, complaint, diagnosis, plan, notes, medication_names, test_names in consultation_specs:
            c, _ = Consultation.objects.update_or_create(
                patient=by_mrn[mrn], doctor=doctors[doc_key], chief_complaint=complaint,
                defaults={'diagnosis': diagnosis, 'treatment_plan': plan, 'notes': notes}
            )
            consults.append(c)
            for med_name in medication_names:
                Prescription.objects.update_or_create(
                    consultation=c, medication=meds[med_name], dosage='As directed',
                    defaults={'frequency': 'See treatment plan', 'quantity': 1 if 'Inhaler' in med_name or 'Gel' in med_name else 14, 'dispensed': med_name not in ['Cefuroxime 250mg']}
                )
            for test_name in test_names:
                status = 'completed' if test_name not in ['Troponin Test', 'Kidney Function Test'] else 'ordered'
                result = 'Result within acceptable range' if status == 'completed' else ''
                LabOrder.objects.update_or_create(
                    consultation=c, test=tests[test_name],
                    defaults={'status': status, 'result': result, 'completed_at': timezone.now() if status == 'completed' else None}
                )

        # ------------------------------------------------------------------
        # 6) Admissions and bed occupancy
        # ------------------------------------------------------------------
        admission_specs = [
            ('MRN0005', 'A-101', 'doctor4', 'Inpatient care for back pain and mobility issue', -10, -4, 'Discharged with physiotherapy advice.'),
            ('MRN0007', 'ICU-02', 'doctor1', 'Cardiac observation after chest pain episode', -5, None, 'Active ICU admission.'),
            ('MRN0003', 'P-014', 'doctor2', 'Paediatric fever observation', -2, None, 'Active paediatric admission.'),
            ('MRN0001', 'E-007', 'doctor1', 'Emergency observation for chest pain', -1, None, 'Short stay observation.'),
            ('MRN0009', 'P-015', 'doctor2', 'Paediatric fever and dehydration monitoring', 0, None, 'Hydration and monitoring.'),
            ('MRN0011', 'A-102', 'doctor4', 'Knee injury observation', -6, -5, 'Discharged after imaging review.'),
        ]
        active_bed_ids = set()
        for mrn, bed_num, doc_key, reason, admitted_offset, discharged_offset, notes in admission_specs:
            discharged_at = aware_at(today + timedelta(days=discharged_offset), 15, 0) if discharged_offset is not None else None
            adm, _ = Admission.objects.update_or_create(
                patient=by_mrn[mrn], bed=beds[bed_num], reason=reason,
                defaults={
                    'doctor': doctors[doc_key],
                    'admitted_at': aware_at(today + timedelta(days=admitted_offset), 8, 0),
                    'discharged_at': discharged_at,
                    'notes': notes,
                }
            )
            if discharged_at is None:
                active_bed_ids.add(beds[bed_num].id)
        Bed.objects.all().update(is_occupied=False)
        Bed.objects.filter(id__in=active_bed_ids).update(is_occupied=True)

        # ------------------------------------------------------------------
        # 7) Bills, bill items, and payments
        # ------------------------------------------------------------------
        bill_specs = [
            ('MRN0005', 'Orthopaedic admission and treatment', 'paid', [('Ward stay - General Ward A', 4, '850.00'), ('Orthopaedic consultation', 1, '750.00'), ('Medication', 1, '350.00')], [('8500.00','card','CARD-ORTH-001', True)]),
            ('MRN0007', 'ICU cardiac observation', 'partial', [('ICU stay', 2, '2500.00'), ('Cardiology consultation', 1, '950.00'), ('Troponin test', 1, '450.00')], [('3000.00','insurance','MEDAID-ICU-002', True), ('1500.00','transfer','EFT-0002', True)]),
            ('MRN0003', 'Paediatric admission', 'unpaid', [('Paediatric ward stay', 2, '950.00'), ('Paediatric consultation', 1, '650.00'), ('CRP test', 1, '220.00')], []),
            ('MRN0001', 'Emergency chest pain observation', 'unpaid', [('Emergency observation', 1, '700.00'), ('Cardiology consultation', 1, '950.00'), ('Troponin test', 1, '450.00')], []),
            ('MRN0009', 'Paediatric fever treatment', 'partial', [('Paediatric ward stay', 1, '950.00'), ('Medication', 1, '220.00'), ('Complete Blood Count', 1, '180.00')], [('500.00','cash','CASH-PED-005', True)]),
            ('MRN0011', 'Knee injury assessment', 'paid', [('Orthopaedic consultation', 1, '750.00'), ('X-ray imaging', 1, '650.00'), ('Medication', 1, '150.00')], [('1550.00','card','CARD-KNEE-006', True)]),
            ('MRN0012', 'Hypertension review', 'partial', [('Cardiology consultation', 1, '950.00'), ('Kidney function test', 1, '280.00'), ('Medication', 1, '180.00')], [('500.00','transfer','EFT-HYP-007', False)]),
            ('MRN0004', 'General medicine chronic review', 'unpaid', [('General consultation', 1, '550.00'), ('Blood glucose test', 1, '85.00'), ('Medication', 1, '120.00')], []),
        ]
        for mrn, desc, status, items, payments in bill_specs:
            bill, _ = Bill.objects.update_or_create(
                patient=by_mrn[mrn], description=desc,
                defaults={'insurance': patient_insurance.get(mrn), 'status': status}
            )
            existing_descriptions = set()
            for item_desc, qty, unit_price in items:
                existing_descriptions.add(item_desc)
                BillItem.objects.update_or_create(
                    bill=bill, description=item_desc,
                    defaults={'quantity': qty, 'unit_price': Decimal(unit_price)}
                )
            BillItem.objects.filter(bill=bill).exclude(description__in=existing_descriptions).delete()

            for amount, method, ref, verified in payments:
                Payment.objects.update_or_create(
                    bill=bill, reference=ref,
                    defaults={'amount': Decimal(amount), 'method': method, 'verified': verified}
                )
            # Keep intended demo statuses stable for screenshots/video.
            Bill.objects.filter(pk=bill.pk).update(status=status)

        self.stdout.write(self.style.SUCCESS('Full demo database seeded successfully.'))
        self.stdout.write('Login accounts:')
        self.stdout.write('  admin / password123')
        self.stdout.write('  doctor1, doctor2, doctor3, doctor4 / password123')
        self.stdout.write('  nurse1, nurse2, nurse3 / password123')
        self.stdout.write('  patient1, patient2, patient3, patient4, patient5, patient6 / password123')
        self.stdout.write('The appointment email feature uses the console backend by default, so emails print in the VS Code terminal during booking/editing.')
