-- =====================================================================
-- Hospital Patient Record System — PostgreSQL schema
-- Run this in pgAdmin (Query Tool) against an empty database, e.g. hospital_db.
-- This file is the SOURCE OF TRUTH for the database structure.
-- Django is configured with managed=False, so it will NOT create or alter
-- these tables. Schema changes go HERE, not in Django migrations.
-- =====================================================================

-- ---------- Django framework tables (required for auth/admin/sessions) ----------
CREATE TABLE django_migrations (
    id              BIGSERIAL PRIMARY KEY,
    app             VARCHAR(255) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    applied         TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE django_content_type (
    id              SERIAL PRIMARY KEY,
    app_label       VARCHAR(100) NOT NULL,
    model           VARCHAR(100) NOT NULL,
    UNIQUE (app_label, model)
);

CREATE TABLE django_session (
    session_key     VARCHAR(40) PRIMARY KEY,
    session_data    TEXT NOT NULL,
    expire_date     TIMESTAMPTZ NOT NULL
);
CREATE INDEX django_session_expire_date_idx ON django_session(expire_date);

CREATE TABLE auth_permission (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    content_type_id INTEGER NOT NULL REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED,
    codename        VARCHAR(100) NOT NULL,
    UNIQUE (content_type_id, codename)
);

CREATE TABLE auth_group (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE auth_group_permissions (
    id              BIGSERIAL PRIMARY KEY,
    group_id        INTEGER NOT NULL REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED,
    permission_id   INTEGER NOT NULL REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED,
    UNIQUE (group_id, permission_id)
);

CREATE TABLE django_admin_log (
    id              SERIAL PRIMARY KEY,
    action_time     TIMESTAMPTZ NOT NULL DEFAULT now(),
    object_id       TEXT,
    object_repr     VARCHAR(200) NOT NULL,
    action_flag     SMALLINT NOT NULL CHECK (action_flag >= 0),
    change_message  TEXT NOT NULL,
    content_type_id INTEGER REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED,
    user_id         BIGINT NOT NULL  -- FK added after accounts_user
);

-- ---------- accounts (custom User extending AbstractUser) ----------
CREATE TABLE accounts_user (
    id              BIGSERIAL PRIMARY KEY,
    password        VARCHAR(128) NOT NULL,
    last_login      TIMESTAMPTZ,
    is_superuser    BOOLEAN      NOT NULL DEFAULT FALSE,
    username        VARCHAR(150) NOT NULL UNIQUE,
    first_name      VARCHAR(150) NOT NULL DEFAULT '',
    last_name       VARCHAR(150) NOT NULL DEFAULT '',
    email           VARCHAR(254) NOT NULL DEFAULT '',
    is_staff        BOOLEAN      NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    date_joined     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    role            VARCHAR(20)  NOT NULL DEFAULT 'patient'
                    CHECK (role IN ('admin','doctor','nurse','patient')),
    phone           VARCHAR(30)  NOT NULL DEFAULT '',
    specialization  VARCHAR(120) NOT NULL DEFAULT ''
);
CREATE INDEX accounts_user_username_idx ON accounts_user(username);

ALTER TABLE django_admin_log
    ADD CONSTRAINT django_admin_log_user_fk
    FOREIGN KEY (user_id) REFERENCES accounts_user(id) DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE accounts_user_groups (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT  NOT NULL REFERENCES accounts_user(id) DEFERRABLE INITIALLY DEFERRED,
    group_id        INTEGER NOT NULL REFERENCES auth_group(id)    DEFERRABLE INITIALLY DEFERRED,
    UNIQUE (user_id, group_id)
);

CREATE TABLE accounts_user_user_permissions (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT  NOT NULL REFERENCES accounts_user(id)    DEFERRABLE INITIALLY DEFERRED,
    permission_id   INTEGER NOT NULL REFERENCES auth_permission(id)  DEFERRABLE INITIALLY DEFERRED,
    UNIQUE (user_id, permission_id)
);

-- ---------- patients ----------
CREATE TABLE patients_patient (
    id                  BIGSERIAL PRIMARY KEY,
    user_id             BIGINT UNIQUE REFERENCES accounts_user(id) ON DELETE SET NULL,
    mrn                 VARCHAR(20)  NOT NULL UNIQUE,
    first_name          VARCHAR(80)  NOT NULL,
    last_name           VARCHAR(80)  NOT NULL,
    date_of_birth       DATE         NOT NULL,
    gender              VARCHAR(1)   NOT NULL CHECK (gender IN ('M','F','O')),
    phone               VARCHAR(30)  NOT NULL DEFAULT '',
    address             TEXT         NOT NULL DEFAULT '',
    blood_group         VARCHAR(5)   NOT NULL DEFAULT '',
    emergency_contact   VARCHAR(120) NOT NULL DEFAULT '',
    allergies           TEXT         NOT NULL DEFAULT '',
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX patients_patient_mrn_idx ON patients_patient(mrn);

-- ---------- appointments ----------
CREATE TABLE appointments_appointment (
    id              BIGSERIAL PRIMARY KEY,
    patient_id      BIGINT      NOT NULL REFERENCES patients_patient(id) ON DELETE CASCADE,
    doctor_id       BIGINT      NOT NULL REFERENCES accounts_user(id)    ON DELETE RESTRICT,
    scheduled_for   TIMESTAMPTZ NOT NULL,
    reason          VARCHAR(200) NOT NULL,
    status          VARCHAR(15) NOT NULL DEFAULT 'scheduled'
                    CHECK (status IN ('scheduled','completed','cancelled','no_show')),
    notes           TEXT        NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX appointments_appt_patient_idx  ON appointments_appointment(patient_id);
CREATE INDEX appointments_appt_doctor_idx   ON appointments_appointment(doctor_id);
CREATE INDEX appointments_appt_when_idx     ON appointments_appointment(scheduled_for);

-- ---------- consultations ----------
CREATE TABLE consultations_consultation (
    id                BIGSERIAL PRIMARY KEY,
    patient_id        BIGINT NOT NULL REFERENCES patients_patient(id) ON DELETE CASCADE,
    doctor_id         BIGINT NOT NULL REFERENCES accounts_user(id)    ON DELETE RESTRICT,
    chief_complaint   VARCHAR(255) NOT NULL,
    diagnosis         TEXT NOT NULL,
    treatment_plan    TEXT NOT NULL DEFAULT '',
    notes             TEXT NOT NULL DEFAULT '',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX consultations_consult_patient_idx ON consultations_consultation(patient_id);
CREATE INDEX consultations_consult_doctor_idx  ON consultations_consultation(doctor_id);

CREATE TABLE consultations_vitals (
    id                  BIGSERIAL PRIMARY KEY,
    patient_id          BIGINT NOT NULL REFERENCES patients_patient(id) ON DELETE CASCADE,
    recorded_by_id      BIGINT REFERENCES accounts_user(id) ON DELETE SET NULL,
    bp_systolic         INTEGER CHECK (bp_systolic  IS NULL OR bp_systolic  >= 0),
    bp_diastolic        INTEGER CHECK (bp_diastolic IS NULL OR bp_diastolic >= 0),
    pulse               INTEGER CHECK (pulse        IS NULL OR pulse        >= 0),
    temperature_c       NUMERIC(4,1),
    respiratory_rate    INTEGER CHECK (respiratory_rate IS NULL OR respiratory_rate >= 0),
    oxygen_saturation   INTEGER CHECK (oxygen_saturation IS NULL OR (oxygen_saturation BETWEEN 0 AND 100)),
    weight_kg           NUMERIC(5,2),
    height_cm           NUMERIC(5,1),
    notes               TEXT NOT NULL DEFAULT '',
    recorded_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX consultations_vitals_patient_idx ON consultations_vitals(patient_id);

-- ---------- pharmacy ----------
CREATE TABLE pharmacy_medication (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(120) NOT NULL UNIQUE,
    description     TEXT         NOT NULL DEFAULT '',
    stock           INTEGER      NOT NULL DEFAULT 0  CHECK (stock >= 0),
    unit_price      NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (unit_price >= 0)
);

CREATE TABLE pharmacy_prescription (
    id                BIGSERIAL PRIMARY KEY,
    consultation_id   BIGINT NOT NULL REFERENCES consultations_consultation(id) ON DELETE CASCADE,
    medication_id     BIGINT NOT NULL REFERENCES pharmacy_medication(id)        ON DELETE RESTRICT,
    dosage            VARCHAR(80) NOT NULL,
    frequency         VARCHAR(80) NOT NULL,
    quantity          INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 0),
    dispensed         BOOLEAN NOT NULL DEFAULT FALSE,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX pharmacy_rx_consult_idx ON pharmacy_prescription(consultation_id);
CREATE INDEX pharmacy_rx_med_idx     ON pharmacy_prescription(medication_id);

-- ---------- laboratory ----------
CREATE TABLE laboratory_labtest (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(120) NOT NULL UNIQUE,
    price           NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (price >= 0)
);

CREATE TABLE laboratory_laborder (
    id                BIGSERIAL PRIMARY KEY,
    consultation_id   BIGINT NOT NULL REFERENCES consultations_consultation(id) ON DELETE CASCADE,
    test_id           BIGINT NOT NULL REFERENCES laboratory_labtest(id)         ON DELETE RESTRICT,
    status            VARCHAR(15) NOT NULL DEFAULT 'ordered'
                      CHECK (status IN ('ordered','completed')),
    result            TEXT NOT NULL DEFAULT '',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at      TIMESTAMPTZ
);
CREATE INDEX laboratory_laborder_consult_idx ON laboratory_laborder(consultation_id);

-- ---------- wards & beds ----------
CREATE TABLE wards_ward (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(80)  NOT NULL UNIQUE,
    description     VARCHAR(200) NOT NULL DEFAULT '',
    daily_rate      NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (daily_rate >= 0)
);

CREATE TABLE wards_bed (
    id              BIGSERIAL PRIMARY KEY,
    ward_id         BIGINT NOT NULL REFERENCES wards_ward(id) ON DELETE CASCADE,
    number          VARCHAR(10) NOT NULL,
    is_occupied     BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (ward_id, number)
);

CREATE TABLE wards_admission (
    id              BIGSERIAL PRIMARY KEY,
    patient_id      BIGINT NOT NULL REFERENCES patients_patient(id) ON DELETE CASCADE,
    bed_id          BIGINT NOT NULL REFERENCES wards_bed(id)        ON DELETE RESTRICT,
    doctor_id       BIGINT NOT NULL REFERENCES accounts_user(id)    ON DELETE RESTRICT,
    reason          VARCHAR(200) NOT NULL,
    admitted_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    discharged_at   TIMESTAMPTZ,
    notes           TEXT NOT NULL DEFAULT ''
);
CREATE INDEX wards_admission_patient_idx ON wards_admission(patient_id);
CREATE INDEX wards_admission_active_idx  ON wards_admission(discharged_at);

-- ---------- insurance ----------
CREATE TABLE insurance_insuranceprovider (
    id                BIGSERIAL PRIMARY KEY,
    name              VARCHAR(120) NOT NULL UNIQUE,
    contact           VARCHAR(120) NOT NULL DEFAULT '',
    coverage_percent  INTEGER NOT NULL DEFAULT 0
                      CHECK (coverage_percent BETWEEN 0 AND 100)
);

CREATE TABLE insurance_patientinsurance (
    id                BIGSERIAL PRIMARY KEY,
    patient_id        BIGINT NOT NULL REFERENCES patients_patient(id)            ON DELETE CASCADE,
    provider_id       BIGINT NOT NULL REFERENCES insurance_insuranceprovider(id) ON DELETE RESTRICT,
    policy_number     VARCHAR(80) NOT NULL,
    coverage_percent  INTEGER NOT NULL DEFAULT 0
                      CHECK (coverage_percent BETWEEN 0 AND 100),
    valid_until       DATE,
    is_active         BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE INDEX insurance_pi_patient_idx ON insurance_patientinsurance(patient_id);

-- ---------- billing ----------
CREATE TABLE billing_bill (
    id              BIGSERIAL PRIMARY KEY,
    patient_id      BIGINT NOT NULL REFERENCES patients_patient(id)         ON DELETE CASCADE,
    insurance_id    BIGINT REFERENCES insurance_patientinsurance(id)        ON DELETE SET NULL,
    description     VARCHAR(200) NOT NULL DEFAULT 'Hospital services',
    status          VARCHAR(15)  NOT NULL DEFAULT 'unpaid'
                    CHECK (status IN ('unpaid','partial','paid')),
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX billing_bill_patient_idx ON billing_bill(patient_id);
CREATE INDEX billing_bill_status_idx  ON billing_bill(status);

CREATE TABLE billing_billitem (
    id              BIGSERIAL PRIMARY KEY,
    bill_id         BIGINT NOT NULL REFERENCES billing_bill(id) ON DELETE CASCADE,
    description     VARCHAR(200) NOT NULL,
    quantity        INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 0),
    unit_price      NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0)
);
CREATE INDEX billing_billitem_bill_idx ON billing_billitem(bill_id);

CREATE TABLE billing_payment (
    id              BIGSERIAL PRIMARY KEY,
    bill_id         BIGINT NOT NULL REFERENCES billing_bill(id) ON DELETE CASCADE,
    amount          NUMERIC(10,2) NOT NULL CHECK (amount >= 0),
    method          VARCHAR(15)   NOT NULL DEFAULT 'cash'
                    CHECK (method IN ('cash','card','insurance','transfer')),
    paid_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    reference       VARCHAR(80) NOT NULL DEFAULT ''
);
CREATE INDEX billing_payment_bill_idx ON billing_payment(bill_id);

-- =====================================================================
-- Mark all built-in Django migrations as already applied so that
--   `python manage.py migrate` is a no-op against this hand-built schema.
-- =====================================================================
INSERT INTO django_migrations (app, name) VALUES
 ('contenttypes','0001_initial'),('contenttypes','0002_remove_content_type_name'),
 ('auth','0001_initial'),('auth','0002_alter_permission_name_max_length'),
 ('auth','0003_alter_user_email_max_length'),('auth','0004_alter_user_username_opts'),
 ('auth','0005_alter_user_last_login_null'),('auth','0006_require_contenttypes_0002'),
 ('auth','0007_alter_validators_add_error_messages'),('auth','0008_alter_user_username_max_length'),
 ('auth','0009_alter_user_last_name_max_length'),('auth','0010_alter_group_name_max_length'),
 ('auth','0011_update_proxy_permissions'),('auth','0012_alter_user_first_name_max_length'),
 ('admin','0001_initial'),('admin','0002_logentry_remove_auto_add'),('admin','0003_logentry_add_action_flag_choices'),
 ('sessions','0001_initial'),
 ('accounts','0001_initial'),('patients','0001_initial'),('appointments','0001_initial'),
 ('consultations','0001_initial'),('pharmacy','0001_initial'),('laboratory','0001_initial'),
 ('wards','0001_initial'),('billing','0001_initial'),('insurance','0001_initial');
