# Database setup (PostgreSQL + pgAdmin)

The full schema lives in **`schema.sql`**. This is the authoritative database
definition — Django models are configured with `managed = False` and will not
create or alter tables.

## Steps

1. In **pgAdmin**, create a database called `hospital_db`
   (or any name; just match the `DB_NAME` env var).
2. Open the **Query Tool** on that database.
3. Run **`schema.sql`** in full. This creates every table, foreign key,
   check constraint, and index — including the Django framework tables
   (`auth_*`, `django_*`, `accounts_user_*`).
4. Run **`seed.sql`** to insert reference data (medications, lab tests,
   wards/beds, insurance providers).
5. From the project root, create the demo accounts:
   ```
   python manage.py seed
   ```
   This uses Django's password hasher to create:
   `admin`, `doctor1`, `nurse1`, `patient1` — all with password `password123`.
6. Start the server: `python manage.py runserver`

## Schema changes

Edit `schema.sql` and apply the diff in pgAdmin (e.g. `ALTER TABLE ...`).
Mirror the change in the matching `models.py` so the ORM layer sees the
new column. Do **not** run `makemigrations` for schema changes.
