-- Seed reference data. Run AFTER schema.sql.
-- For demo USERS (with proper Django password hashes) run instead:
--    python manage.py seed
-- which creates admin/doctor1/nurse1/patient1 (password: password123).

INSERT INTO pharmacy_medication (name, stock, unit_price) VALUES
 ('Paracetamol 500mg', 100, 0.50),
 ('Amoxicillin 250mg', 100, 1.20),
 ('Ibuprofen 400mg',   100, 0.80)
ON CONFLICT (name) DO NOTHING;

INSERT INTO laboratory_labtest (name, price) VALUES
 ('Complete Blood Count', 15),
 ('Urinalysis',           10),
 ('Blood Glucose',         8)
ON CONFLICT (name) DO NOTHING;

INSERT INTO wards_ward (name, description, daily_rate) VALUES
 ('General Ward A', 'Main inpatient ward',  50),
 ('Pediatric Ward', 'Children under 12',    60),
 ('ICU',            'Intensive care',      200)
ON CONFLICT (name) DO NOTHING;

INSERT INTO wards_bed (ward_id, number)
SELECT w.id, b.num FROM wards_ward w
CROSS JOIN (VALUES ('101'),('102'),('103'),('104')) AS b(num)
WHERE w.name = 'General Ward A'
ON CONFLICT (ward_id, number) DO NOTHING;

INSERT INTO insurance_insuranceprovider (name, contact, coverage_percent) VALUES
 ('HealthPlus',    'support@healthplus.example',  70),
 ('MediCover',     '+1-555-0199',                 60),
 ('NationalCare',  'claims@natcare.example',      80)
ON CONFLICT (name) DO NOTHING;
