from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User

class StaffCreateForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username','first_name','last_name','email','phone','role','specialization')

ROLE_CHOICES = [
    ('patient','Patient'),
    ('doctor','Doctor'),
    ('nurse','Nurse'),
]

class SignUpForm(UserCreationForm):
    role = forms.ChoiceField(choices=ROLE_CHOICES, widget=forms.Select(attrs={'id':'id_role'}))
    first_name = forms.CharField(max_length=80, required=True)
    last_name  = forms.CharField(max_length=80, required=True)
    email      = forms.EmailField(required=True)
    phone      = forms.CharField(max_length=30, required=False)
    # patient-only
    date_of_birth = forms.DateField(required=False, widget=forms.DateInput(attrs={'type':'date'}))
    gender = forms.ChoiceField(required=False, choices=[('','—'),('M','Male'),('F','Female'),('O','Other')])
    # doctor-only
    specialization = forms.CharField(max_length=120, required=False,
        help_text='e.g. Cardiology, Pediatrics (doctors only)')

    class Meta:
        model = User
        fields = ('role','username','first_name','last_name','email','phone','password1','password2')

    def clean(self):
        data = super().clean()
        role = data.get('role')
        if role == 'patient':
            if not data.get('date_of_birth'):
                self.add_error('date_of_birth','Required for patient signup.')
            if not data.get('gender'):
                self.add_error('gender','Required for patient signup.')
        if role == 'doctor' and not data.get('specialization'):
            self.add_error('specialization','Required for doctor signup.')
        return data

    def save(self, commit=True):
        user = super().save(commit=False)
        role = self.cleaned_data['role']
        user.role = role
        user.first_name = self.cleaned_data['first_name']
        user.last_name  = self.cleaned_data['last_name']
        user.email      = self.cleaned_data['email']
        user.phone      = self.cleaned_data.get('phone','')
        if role == 'doctor':
            user.specialization = self.cleaned_data.get('specialization','')
        if commit:
            user.save()
            if role == 'patient':
                from patients.models import Patient
                last = Patient.objects.order_by('-id').first()
                next_num = (last.id + 1) if last else 1
                mrn = f'MRN{next_num:04d}'
                while Patient.objects.filter(mrn=mrn).exists():
                    next_num += 1
                    mrn = f'MRN{next_num:04d}'
                Patient.objects.create(
                    user=user, mrn=mrn,
                    first_name=user.first_name, last_name=user.last_name,
                    date_of_birth=self.cleaned_data['date_of_birth'],
                    gender=self.cleaned_data['gender'],
                    phone=user.phone,
                )
        return user
