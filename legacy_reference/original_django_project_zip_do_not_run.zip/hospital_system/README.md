# Hospital Patient Record System (Django + PostgreSQL, raw SQL schema)

A clean, role-based hospital management system. The database schema is defined
in **raw SQL** (`sql/schema.sql`) and runs in **PostgreSQL** — visible and
editable directly in pgAdmin. Django's ORM is used for queries only; it does
not own the schema (`managed = False` on every model).

## Features
- Patients, Appointments, Consultations & Vitals
- Pharmacy (managed by doctors), Laboratory
- Wards & Beds with admissions / discharges
- Billing with line items + insurance coverage
- Insurance providers & patient policies
- 4 roles: Admin/Receptionist, Doctor, Nurse, Patient
- Polished public landing page at `/`

## Local setup

### 1. PostgreSQL (via pgAdmin)
1. In pgAdmin, **create database** `hospital_db`.
2. Open the **Query Tool** on `hospital_db`.
3. Run **`sql/schema.sql`** in full (creates all tables, FKs, indexes).
4. Run **`sql/seed.sql`** (medications, labs, wards, insurance providers).

> Or via CLI:
> ```
> createdb hospital_db
> psql -d hospital_db -f sql/schema.sql
> psql -d hospital_db -f sql/seed.sql
> ```

### 2. Django app
```
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Set DB credentials (defaults shown):
```
export DB_NAME=hospital_db
export DB_USER=postgres
export DB_PASSWORD=postgres
export DB_HOST=localhost
export DB_PORT=5432
```

Create demo users (uses Django's password hasher):
```
python manage.py seed
```

Run:
```
python manage.py runserver
```
Visit **http://127.0.0.1:8000/** — public landing page.
Click **Sign in** and use one of:
- `admin` / `password123`  (Admin / Receptionist)
- `doctor1` / `password123`
- `nurse1` / `password123`
- `patient1` / `password123`

## Schema changes
Edit `sql/schema.sql`, apply the diff in pgAdmin (`ALTER TABLE ...`), then mirror
the change in the matching `models.py`. Do **not** run `makemigrations` —
all models are `managed=False` and the empty `0001_initial.py` migrations
are intentional.

## Project layout
```
hospital_system/      Django project (settings, urls, wsgi)
accounts/             Custom User + auth
patients/             Patient registry
appointments/         Doctor scheduling
consultations/        Visits + nurse vitals
pharmacy/             Medications + prescriptions
laboratory/           Lab tests + orders
wards/                Wards, beds, admissions
billing/              Bills, items, payments
insurance/            Providers + patient policies
dashboard/            Landing page + role dashboards
templates/            All HTML templates
sql/
  schema.sql          ← source of truth for the database
  seed.sql            reference data
  README.md           pgAdmin instructions
```
