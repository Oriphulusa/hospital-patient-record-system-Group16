from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Bill, BillItem, Payment
from .forms import BillForm, BillItemForm, PaymentForm, PatientPaymentForm

@login_required
def bill_list(request):
    u=request.user; qs=Bill.objects.select_related('patient','insurance')
    if u.is_patient(): qs=qs.filter(patient__user=u)
    return render(request,'billing/list.html',{'bills':qs})

@login_required
def bill_create(request):
    if not request.user.is_admin(): return redirect('billing:list')
    form=BillForm(request.POST or None)
    if form.is_valid():
        b=form.save(); return redirect('billing:detail', pk=b.pk)
    return render(request,'billing/form.html',{'form':form,'title':'New Bill'})

@login_required
def bill_detail(request, pk):
    b=get_object_or_404(Bill, pk=pk)
    u=request.user
    if u.is_patient() and b.patient.user_id != u.id: return redirect('billing:list')
    return render(request,'billing/detail.html',{'b':b,
        'item_form':BillItemForm(),
        'pay_form':PaymentForm(),
        'patient_pay_form':PatientPaymentForm(initial={'amount':b.balance()}),
    })

@login_required
def add_item(request, pk):
    if not request.user.is_admin(): return redirect('billing:detail', pk=pk)
    b=get_object_or_404(Bill, pk=pk)
    form=BillItemForm(request.POST or None)
    if form.is_valid():
        i=form.save(commit=False); i.bill=b; i.save(); b.refresh_status()
    return redirect('billing:detail', pk=pk)

@login_required
def add_payment(request, pk):
    """Admin records a verified payment (cash/card)."""
    if not request.user.is_admin(): return redirect('billing:detail', pk=pk)
    b=get_object_or_404(Bill, pk=pk)
    form=PaymentForm(request.POST or None)
    if form.is_valid():
        p=form.save(commit=False); p.bill=b; p.verified=True; p.save(); b.refresh_status()
    return redirect('billing:detail', pk=pk)

@login_required
def submit_proof(request, pk):
    """Patient uploads proof of payment for admin to verify."""
    b=get_object_or_404(Bill, pk=pk)
    if not request.user.is_patient() or b.patient.user_id != request.user.id:
        return redirect('billing:detail', pk=pk)
    form=PatientPaymentForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        p=form.save(commit=False); p.bill=b; p.verified=False; p.save()
        messages.success(request, 'Proof of payment uploaded. Awaiting verification by admin.')
    else:
        messages.error(request, 'Please upload a valid proof file and amount.')
    return redirect('billing:detail', pk=pk)

@login_required
def verify_payment(request, pk, payment_id):
    if not request.user.is_admin(): return redirect('billing:detail', pk=pk)
    p=get_object_or_404(Payment, pk=payment_id, bill_id=pk)
    p.verified=True; p.save(update_fields=['verified'])
    p.bill.refresh_status()
    messages.success(request,'Payment verified.')
    return redirect('billing:detail', pk=pk)
