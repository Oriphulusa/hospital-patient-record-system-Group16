from django import forms
from .models import Bill, BillItem, Payment

class BillForm(forms.ModelForm):
    class Meta: model=Bill; fields=['patient','insurance','description']

class BillItemForm(forms.ModelForm):
    class Meta: model=BillItem; fields=['description','quantity','unit_price']

class PaymentForm(forms.ModelForm):
    """Admin records payment (cash/card etc.)"""
    class Meta:
        model = Payment
        fields = ['amount','method','reference']

class PatientPaymentForm(forms.ModelForm):
    """Patient submits proof of payment (bank transfer / online)."""
    proof_of_payment = forms.FileField(required=True,
        help_text='Upload screenshot or PDF of your payment receipt.')
    class Meta:
        model = Payment
        fields = ['amount','method','reference','proof_of_payment']
        widgets = {
            'method': forms.Select(choices=[('transfer','Bank Transfer'),('card','Card / Online')]),
            'reference': forms.TextInput(attrs={'placeholder':'Transaction reference'}),
        }
